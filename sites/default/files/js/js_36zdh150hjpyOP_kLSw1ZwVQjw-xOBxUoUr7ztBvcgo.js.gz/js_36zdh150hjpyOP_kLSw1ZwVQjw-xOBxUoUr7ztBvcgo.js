Drupal.locale = { 'pluralFormula': function ($n) { return Number(($n!=1)); }, 'strings': {"":{"An AJAX HTTP error occurred.":"Hubo un error HTTP AJAX.","HTTP Result Code: !status":"C\u00f3digo de Resultado HTTP: !status","An AJAX HTTP request terminated abnormally.":"Una solicitud HTTP de AJAX termin\u00f3 de manera anormal.","Debugging information follows.":"A continuaci\u00f3n se detalla la informaci\u00f3n de depuraci\u00f3n.","Path: !uri":"Ruta: !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseText: !responseText","ReadyState: !readyState":"ReadyState: !readyState","Loading":"Cargando","(active tab)":"(solapa activa)","Hide":"Ocultar","Show":"Mostrar","Re-order rows by numerical weight instead of dragging.":"Reordenar las filas por peso num\u00e9rico en lugar de arrastrar.","Show row weights":"Mostrar pesos de la fila","Hide row weights":"Ocultar pesos de la fila","Drag to re-order":"Arrastre para reordenar","Changes made in this table will not be saved until the form is submitted.":"Los cambios realizados en esta tabla no se guardar\u00e1n hasta que se env\u00ede el formulario","Hide shortcuts":"Ocultar atajos","@title dialog":"Di\u00e1logo @title","Configure":"Configurar","Show shortcuts":"Mostrar atajos","Customize dashboard":"Personalizar panel de control","Edit":"Editar","Add":"Agregar","All":"Todo(s)","Done":"Hecho","Select all rows in this table":"Seleccionar todas las filas de esta tabla","Deselect all rows in this table":"Quitar la selecci\u00f3n a todas las filas de esta tabla","Not published":"No publicado","Please wait...":"Espere, por favor...","By @name on @date":"Por @name en @date","By @name":"Por @name","Not in menu":"No est\u00e1 en un men\u00fa","Alias: @alias":"Alias: @alias","No alias":"Sin alias","New revision":"Nueva revisi\u00f3n","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"Los cambios sobre estos bloques no se guardar\u00e1n hasta que no pulse el bot\u00f3n \u003Cem\u003EGuardar bloques\u003C\/em\u003E.","This permission is inherited from the authenticated user role.":"Este permiso se hereda del rol de usuario registrado.","No revision":"Sin revisi\u00f3n","@number comments per page":"@number comentarios por p\u00e1gina","Requires a title":"Necesita un t\u00edtulo","Not restricted":"Sin restricci\u00f3n","Not customizable":"No personalizable","Restricted to certain pages":"Restringido a algunas p\u00e1ginas","The block cannot be placed in this region.":"El bloque no se puede colocar en esta regi\u00f3n.","Hide summary":"Ocultar resumen","Edit summary":"Editar resumen","Don\u0027t display post information":"No mostrar informaci\u00f3n del env\u00edo","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"El archivo seleccionado %filename no puede ser subido. Solo se permiten archivos con las siguientes extensiones: %extensions.","Autocomplete popup":"Ventana emergente con autocompletado","Searching for matches...":"Buscando coincidencias","Automatic alias":"Alias autom\u00e1tico","Remove group":"Eliminar grupo","Apply (all displays)":"Aplicar (todas las presentaciones)","Revert to default":"Volver al valor inicial","Apply (this display)":"Aplicar (esta presentaci\u00f3n)","Translate Text":"Traducir texto","An HTTP error @status occured.":"Ha ocurrido un error de HTTP @status.","Show description":"Mostrar descripci\u00f3n","Hide description":"Esconder descripci\u00f3n","Also allow !name role to !permission?":"\u00bfTambi\u00e9n permitir al rol !name el permiso !permission?","New":"Nuevo","Available tokens":"Comodines disponibles","Insert this token into your form":"Inserte este comod\u00edn en su formulario","Loading token browser...":"Cargando navegador de comodines...","Show layout designer":"Mostrar maquetador de dise\u00f1o.","Hide layout designer":"Ocultar el maquetador de dise\u00f1o","Remove this pane?":"\u00bfEliminar este panel?","Recent":"Reciente","Ignored from settings":"Ignorado por los ajustes","Pause":"Pausa"}} };;
(function ($) {

Drupal.behaviors.menu_block = {
  attach: function (context, settings) {
    // This behavior attaches by ID, so is only valid once on a page.
    if ($('#menu-block-settings.menu-block-processed').size()) {
      return;
    }
    $('#menu-block-settings', context).addClass('menu-block-processed');

    // Show the "display options" if javascript is on.
    $('.form-item-display-options.form-type-radios>label', context).addClass('element-invisible');
    $('.form-item-display-options.form-type-radios', context).show();
    // Make the radio set into a jQuery UI buttonset.
    $('#edit-display-options', context).buttonset();

    // Override the default show/hide animation for Form API states.
    $('#menu-block-settings', context).bind('state:visible', function(e) {
      if (e.trigger) {
        e.stopPropagation() /* Stop the handler further up the tree. */
        $(e.target).closest('.form-item, .form-wrapper')[e.value ? 'slideDown' : 'slideUp']('fast');
      }
    });

    // Syncronize the display of menu and parent item selects.
    $('.menu-block-parent-mlid', context).change( function() {
      var menuItem = $(this).val().split(':');
      $('.menu-block-menu-name').val(menuItem[0]);
    });
    $('.menu-block-menu-name', context).change( function() {
      $('.menu-block-parent-mlid').val($(this).val() + ':0');
    });
  }
};

})(jQuery);
;
